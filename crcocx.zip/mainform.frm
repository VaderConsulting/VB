VERSION 5.00
Object = "{5E969A41-5923-11D0-B191-444553540000}#1.5#0"; "CRCCTRL.OCX"
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form mainform 
   Caption         =   "Test CRC OCX"
   ClientHeight    =   5655
   ClientLeft      =   1200
   ClientTop       =   1980
   ClientWidth     =   8850
   ForeColor       =   &H00404040&
   LinkTopic       =   "Form1"
   PaletteMode     =   1  'UseZOrder
   Picture         =   "mainform.frx":0000
   ScaleHeight     =   5655
   ScaleWidth      =   8850
   Begin VB.Frame Frame8 
      Caption         =   "Custom CRC"
      Height          =   1515
      Left            =   60
      TabIndex        =   52
      Top             =   3330
      Width           =   4305
      Begin VB.CommandButton cmdInitCust 
         Caption         =   "Initialize Custom"
         Height          =   315
         Left            =   1320
         TabIndex        =   64
         Top             =   1140
         Width           =   2895
      End
      Begin VB.TextBox txtCustXOR 
         BeginProperty Font 
            Name            =   "Fixedsys"
            Size            =   9
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   285
         Left            =   2820
         TabIndex        =   63
         Text            =   "FFFFFFFF"
         Top             =   780
         Width           =   1395
      End
      Begin VB.TextBox txtCustPoly 
         BeginProperty Font 
            Name            =   "Fixedsys"
            Size            =   9
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   285
         Left            =   2820
         TabIndex        =   62
         Text            =   "04C11DB7"
         Top             =   480
         Width           =   1395
      End
      Begin VB.TextBox txtCustSeed 
         BeginProperty Font 
            Name            =   "Fixedsys"
            Size            =   9
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   285
         Left            =   2820
         TabIndex        =   61
         Text            =   "FFFFFFFF"
         Top             =   180
         Width           =   1395
      End
      Begin VB.CheckBox chkReflectOP 
         Caption         =   "Reflect OP"
         Height          =   225
         Left            =   150
         TabIndex        =   56
         Top             =   1140
         Value           =   1  'Checked
         Width           =   1125
      End
      Begin VB.CheckBox chkReflectIP 
         Caption         =   "Reflect IP"
         Height          =   255
         Left            =   150
         TabIndex        =   55
         Top             =   840
         Value           =   1  'Checked
         Width           =   1065
      End
      Begin VB.OptionButton opt32 
         Caption         =   "32 Bit"
         Height          =   225
         Left            =   150
         TabIndex        =   54
         Top             =   540
         Value           =   -1  'True
         Width           =   765
      End
      Begin VB.OptionButton opt16 
         Caption         =   "16 Bit"
         Height          =   225
         Left            =   150
         TabIndex        =   53
         Top             =   240
         Width           =   765
      End
      Begin VB.Label Label8 
         Caption         =   "XOR output (HEX)"
         Height          =   225
         Left            =   1380
         TabIndex        =   60
         Top             =   810
         Width           =   1305
      End
      Begin VB.Label Label7 
         Caption         =   "Polynomial (HEX)"
         Height          =   225
         Left            =   1380
         TabIndex        =   59
         Top             =   510
         Width           =   1245
      End
      Begin VB.Label Label5 
         Caption         =   "Seed (HEX)"
         Height          =   225
         Left            =   1380
         TabIndex        =   57
         Top             =   210
         Width           =   885
      End
   End
   Begin VB.Frame Frame7 
      Caption         =   "Files (Asynchronus)"
      Height          =   3945
      Left            =   4440
      TabIndex        =   31
      Top             =   900
      Width           =   4335
      Begin VB.CommandButton cmdAsyncStop 
         Caption         =   "Stop"
         Height          =   315
         Index           =   4
         Left            =   3780
         TabIndex        =   51
         TabStop         =   0   'False
         Top             =   630
         Width           =   495
      End
      Begin VB.CommandButton cmdAsyncStop 
         Caption         =   "Stop"
         Height          =   315
         Index           =   1
         Left            =   3780
         TabIndex        =   50
         TabStop         =   0   'False
         Top             =   1545
         Width           =   495
      End
      Begin VB.CommandButton cmdAsyncStop 
         Caption         =   "Stop"
         Height          =   315
         Index           =   2
         Left            =   3780
         TabIndex        =   49
         TabStop         =   0   'False
         Top             =   2460
         Width           =   495
      End
      Begin VB.CommandButton cmdAsyncStop 
         Caption         =   "Stop"
         Height          =   315
         Index           =   3
         Left            =   3780
         TabIndex        =   48
         TabStop         =   0   'False
         Top             =   3360
         Width           =   495
      End
      Begin VB.TextBox txtAsyncRes 
         BackColor       =   &H8000000F&
         BorderStyle     =   0  'None
         Height          =   195
         Index           =   3
         Left            =   90
         Locked          =   -1  'True
         TabIndex        =   47
         Text            =   "Result"
         Top             =   3330
         Width           =   3645
      End
      Begin VB.TextBox txtAsyncRes 
         BackColor       =   &H8000000F&
         BorderStyle     =   0  'None
         Height          =   195
         Index           =   2
         Left            =   90
         Locked          =   -1  'True
         TabIndex        =   46
         Text            =   "Result"
         Top             =   2418
         Width           =   3645
      End
      Begin VB.TextBox txtAsyncRes 
         BackColor       =   &H8000000F&
         BorderStyle     =   0  'None
         Height          =   195
         Index           =   1
         Left            =   90
         Locked          =   -1  'True
         TabIndex        =   45
         Text            =   "Result"
         Top             =   1506
         Width           =   3645
      End
      Begin VB.TextBox txtAsyncRes 
         BackColor       =   &H8000000F&
         BorderStyle     =   0  'None
         Height          =   195
         Index           =   4
         Left            =   90
         Locked          =   -1  'True
         TabIndex        =   44
         Text            =   "Result"
         Top             =   594
         Width           =   3645
      End
      Begin VB.CommandButton cmdAsync 
         Caption         =   "Go"
         Height          =   315
         Index           =   3
         Left            =   3780
         TabIndex        =   42
         TabStop         =   0   'False
         Top             =   3006
         Width           =   495
      End
      Begin VB.TextBox txtAsync 
         Height          =   285
         Index           =   3
         Left            =   90
         TabIndex        =   41
         Text            =   "testdata.dat"
         Top             =   3006
         Width           =   3645
      End
      Begin VB.CommandButton cmdAsync 
         Caption         =   "Go"
         Height          =   315
         Index           =   2
         Left            =   3780
         TabIndex        =   39
         TabStop         =   0   'False
         Top             =   2094
         Width           =   495
      End
      Begin VB.TextBox txtAsync 
         Height          =   285
         Index           =   2
         Left            =   90
         TabIndex        =   38
         Text            =   "testdata.dat"
         Top             =   2094
         Width           =   3645
      End
      Begin VB.CommandButton cmdAsync 
         Caption         =   "Go"
         Height          =   315
         Index           =   1
         Left            =   3780
         TabIndex        =   36
         TabStop         =   0   'False
         Top             =   1182
         Width           =   495
      End
      Begin VB.TextBox txtAsync 
         Height          =   285
         Index           =   1
         Left            =   90
         TabIndex        =   35
         Text            =   "testdata.dat"
         Top             =   1182
         Width           =   3645
      End
      Begin MSComctlLib.ProgressBar barAsync 
         Height          =   225
         Index           =   4
         Left            =   90
         TabIndex        =   34
         Top             =   825
         Width           =   3645
         _ExtentX        =   6429
         _ExtentY        =   397
         _Version        =   393216
         Appearance      =   1
      End
      Begin VB.CommandButton cmdAsync 
         Caption         =   "Go"
         Height          =   315
         Index           =   4
         Left            =   3780
         TabIndex        =   33
         TabStop         =   0   'False
         Top             =   270
         Width           =   495
      End
      Begin VB.TextBox txtAsync 
         Height          =   285
         Index           =   4
         Left            =   90
         TabIndex        =   32
         Text            =   "testdata.dat"
         Top             =   270
         Width           =   3645
      End
      Begin MSComctlLib.ProgressBar barAsync 
         Height          =   225
         Index           =   1
         Left            =   90
         TabIndex        =   37
         Top             =   1740
         Width           =   3645
         _ExtentX        =   6429
         _ExtentY        =   397
         _Version        =   393216
         Appearance      =   1
      End
      Begin MSComctlLib.ProgressBar barAsync 
         Height          =   225
         Index           =   2
         Left            =   90
         TabIndex        =   40
         Top             =   2655
         Width           =   3645
         _ExtentX        =   6429
         _ExtentY        =   397
         _Version        =   393216
         Appearance      =   1
      End
      Begin MSComctlLib.ProgressBar barAsync 
         Height          =   225
         Index           =   3
         Left            =   90
         TabIndex        =   43
         Top             =   3570
         Width           =   3645
         _ExtentX        =   6429
         _ExtentY        =   397
         _Version        =   393216
         Appearance      =   1
      End
      Begin VB.Line Line2 
         Index           =   2
         X1              =   90
         X2              =   4230
         Y1              =   2940
         Y2              =   2940
      End
      Begin VB.Line Line2 
         Index           =   1
         X1              =   90
         X2              =   4230
         Y1              =   2010
         Y2              =   2010
      End
      Begin VB.Line Line2 
         Index           =   0
         X1              =   90
         X2              =   4260
         Y1              =   1110
         Y2              =   1110
      End
   End
   Begin VB.Frame Frame6 
      Caption         =   "File (Synchronus)"
      Height          =   765
      Left            =   4440
      TabIndex        =   28
      Top             =   60
      Width           =   4335
      Begin VB.TextBox txtFile 
         Height          =   345
         Left            =   120
         TabIndex        =   30
         Text            =   "testdata.dat"
         Top             =   300
         Width           =   3585
      End
      Begin VB.CommandButton cmdFile 
         Caption         =   "Go"
         Height          =   345
         Left            =   3780
         TabIndex        =   29
         TabStop         =   0   'False
         Top             =   300
         Width           =   495
      End
   End
   Begin VB.Frame Frame5 
      Caption         =   "testdata.dat"
      Height          =   1185
      Left            =   60
      TabIndex        =   21
      Top             =   2130
      Width           =   4305
      Begin VB.CheckBox chkSeed 
         Caption         =   "Use seed"
         Height          =   375
         Left            =   3360
         TabIndex        =   65
         Top             =   180
         Width           =   795
      End
      Begin VB.CommandButton Command9 
         Caption         =   "Init VB"
         Height          =   345
         Left            =   150
         TabIndex        =   24
         TabStop         =   0   'False
         Top             =   690
         Width           =   675
      End
      Begin VB.CommandButton Command10 
         Caption         =   "Do VB"
         Enabled         =   0   'False
         Height          =   345
         Left            =   1020
         TabIndex        =   23
         TabStop         =   0   'False
         Top             =   690
         Width           =   675
      End
      Begin VB.CommandButton cmdDoCRC 
         Caption         =   "DoCRCByteArray"
         Height          =   345
         Left            =   180
         TabIndex        =   22
         TabStop         =   0   'False
         Top             =   240
         Width           =   1545
      End
      Begin VB.Label Label4 
         Caption         =   "Hide the control to speed up!"
         Height          =   375
         Left            =   1860
         TabIndex        =   26
         Top             =   240
         Width           =   1275
      End
      Begin VB.Line Line1 
         X1              =   60
         X2              =   4230
         Y1              =   630
         Y2              =   630
      End
      Begin VB.Label Label3 
         Caption         =   "For comparison, VB modbus16, courtesy of Leandro Barajas"
         Height          =   405
         Left            =   1860
         TabIndex        =   25
         Top             =   660
         Width           =   2205
      End
   End
   Begin VB.Frame Frame4 
      Caption         =   "Results"
      Height          =   885
      Left            =   60
      TabIndex        =   16
      Top             =   60
      Width           =   4275
      Begin VB.Label lblResult 
         Caption         =   "0"
         Height          =   285
         Left            =   750
         TabIndex        =   20
         Top             =   570
         Width           =   3345
      End
      Begin VB.Label lblticks 
         Caption         =   " "
         Height          =   285
         Left            =   750
         TabIndex        =   19
         Top             =   180
         Width           =   3345
      End
      Begin VB.Label Label1 
         Caption         =   "Speed"
         Height          =   285
         Left            =   150
         TabIndex        =   18
         Top             =   240
         Width           =   585
      End
      Begin VB.Label Label2 
         Caption         =   "CRC"
         Height          =   285
         Left            =   150
         TabIndex        =   17
         Top             =   570
         Width           =   495
      End
   End
   Begin VB.Frame Frame3 
      Caption         =   "OCX"
      Height          =   1035
      Left            =   60
      TabIndex        =   12
      Top             =   1020
      Width           =   4275
      Begin VB.CheckBox chkExtend 
         Caption         =   "Extend sample"
         Height          =   375
         Left            =   3360
         TabIndex        =   27
         Top             =   600
         Width           =   795
      End
      Begin VB.CommandButton cmdVisible 
         Caption         =   "Hide"
         Height          =   285
         Left            =   3420
         TabIndex        =   15
         TabStop         =   0   'False
         Top             =   240
         Width           =   765
      End
      Begin VB.ComboBox crclist 
         Height          =   315
         ItemData        =   "mainform.frx":0446
         Left            =   120
         List            =   "mainform.frx":046E
         TabIndex        =   14
         Text            =   "Crc type"
         Top             =   570
         Width           =   3165
      End
      Begin CRCCTRLLib.CrcCtrl crcTest 
         Height          =   225
         Left            =   120
         TabIndex        =   13
         Top             =   240
         Width           =   3165
         _Version        =   65541
         _ExtentX        =   5583
         _ExtentY        =   397
         _StockProps     =   0
      End
   End
   Begin VB.Frame Frame2 
      Caption         =   "CRC of Strings"
      Height          =   705
      Left            =   60
      TabIndex        =   8
      Top             =   4890
      Width           =   4305
      Begin VB.TextBox txtCRC 
         Height          =   315
         Left            =   2070
         TabIndex        =   11
         Text            =   "Hello World"
         Top             =   240
         Width           =   2115
      End
      Begin VB.CommandButton Command1 
         Caption         =   "DoCRC"
         Height          =   345
         Left            =   90
         TabIndex        =   10
         TabStop         =   0   'False
         Top             =   240
         Width           =   795
      End
      Begin VB.CommandButton Command2 
         Caption         =   "DoCRCVar"
         Height          =   345
         Left            =   930
         TabIndex        =   9
         TabStop         =   0   'False
         Top             =   240
         Width           =   1095
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "DoCRCVar"
      Height          =   675
      Left            =   4440
      TabIndex        =   0
      Top             =   4920
      Width           =   4335
      Begin VB.TextBox numCRC 
         Height          =   315
         Left            =   3480
         TabIndex        =   7
         Text            =   "42"
         Top             =   240
         Width           =   705
      End
      Begin VB.CommandButton Command3 
         Caption         =   "Dbl"
         Height          =   345
         Left            =   90
         TabIndex        =   6
         TabStop         =   0   'False
         Top             =   240
         Width           =   465
      End
      Begin VB.CommandButton Command4 
         Caption         =   "Long"
         Height          =   345
         Left            =   600
         TabIndex        =   5
         TabStop         =   0   'False
         Top             =   240
         Width           =   525
      End
      Begin VB.CommandButton Command5 
         Caption         =   "Date"
         Height          =   345
         Left            =   1170
         TabIndex        =   4
         TabStop         =   0   'False
         Top             =   240
         Width           =   525
      End
      Begin VB.CommandButton Command6 
         Caption         =   "Byte"
         Height          =   345
         Left            =   1740
         TabIndex        =   3
         TabStop         =   0   'False
         Top             =   240
         Width           =   525
      End
      Begin VB.CommandButton Command7 
         Caption         =   "Sngl"
         Height          =   345
         Left            =   2310
         TabIndex        =   2
         TabStop         =   0   'False
         Top             =   240
         Width           =   525
      End
      Begin VB.CommandButton Command8 
         Caption         =   "Int"
         Height          =   345
         Left            =   2880
         TabIndex        =   1
         TabStop         =   0   'False
         Top             =   240
         Width           =   525
      End
   End
   Begin VB.Label Label6 
      Caption         =   "Seed (HEX)"
      Height          =   225
      Left            =   1650
      TabIndex        =   58
      Top             =   3900
      Width           =   885
   End
   Begin VB.Menu mnuQuit 
      Caption         =   "&Quit"
   End
   Begin VB.Menu mnuMine 
      Caption         =   "Experimetal"
   End
End
Attribute VB_Name = "mainform"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Dim Data() As Byte

Dim Cnt As Long
Dim seed As Long
Dim tickstart As Long
Dim ticks As Long

Dim cTimer As CMMTimer

Private Sub cmdAsync_Click(Index As Integer)

    txtAsyncRes(Index) = "Start: " & crcTest.DoCRCFileAsyncStart(txtAsync(Index), Index)
    
End Sub

Private Sub cmdAsyncStop_Click(Index As Integer)

    txtAsyncRes(Index) = "Stop:  " & crcTest.DoCRCFileAsyncStop(Index)

End Sub


Private Sub cmdCustom_Click()

End Sub

Private Sub cmdDoCRC_Click()
    Dim looper As Long
    Dim its As Long
    
    lblticks = "Stated"
    
    seed = Val("&H" & txtCustSeed)
    
    ' do in a loop to get 1/2 MB data
    its = 524288 \ Cnt
    If its = 0 Then its = 1
    
    cTimer.StartTimer
    
    If chkExtend.Value = vbChecked Then
        For looper = 1 To its
            crcTest.DoCRCByteArray Data, Cnt, (chkSeed.Value = vbChecked), seed
        Next
    Else
        crcTest.DoCRCByteArray Data, Cnt, (chkSeed.Value = vbChecked), seed
    End If
    
    lblResult = crcTest.GetCRCHexStr
    If lblResult = "0" Then lblResult = "error " & crcTest.GetLastError
    
    cTimer.StopTimer
    ticks = cTimer.MilliSeconds
    If ticks = 0 Then ticks = 1
    
    lblticks = Format$(((Cnt * its / 1048576) / (ticks / 1000)), "0.000") & "  MB/s  (" & ticks & " milliseconds)"
    
End Sub


Public Function StrAddress(ByVal StrRef As Long) As Long
    StrAddress = CLng(StrRef)
End Function

'Private Sub cmdPrep_Click()
'
'    crcTest.PrepCustom _
'        CLng("&H" & txtPoly), _
'        chk32Bit.Value = vbChecked, _
'        chkRev.Value = vbChecked
'
'End Sub

Private Sub cmdFile_Click()
    
    Dim looper As Long
    Dim fnum As Integer
    
    fnum = FreeFile
    Open txtFile For Binary Access Read As #fnum
    Cnt = LOF(fnum)
    Close #fnum

    lblticks = "Stated"
    
    cTimer.StartTimer
    
    crcTest.DoCRCFile txtFile
    
    lblResult = crcTest.GetCRCHexStr
    If lblResult = "0" Then lblResult = "error " & crcTest.GetLastError
    
    cTimer.StopTimer
    ticks = cTimer.MilliSeconds
    If ticks = 0 Then ticks = 1
    
    ' cnt = bytes
    ' ticks = ms
    
    lblticks = Format$(((Cnt / 1048576) / (ticks / 1000)), "0.000") & "  MB/s  (" & ticks & " milliseconds)"

End Sub

Private Sub cmdInitCust_Click()
    
    Dim bytes As Integer
    Dim poly As Long
    Dim xorop As Long
    Dim reflectip As Integer
    Dim reflectop As Integer
    
    If opt16.Value = True Then bytes = 2 Else bytes = 4
    seed = Val("&H" & txtCustSeed)
    poly = Val("&H" & txtCustPoly)
    xorop = Val("&H" & txtCustXOR)
    If chkReflectOP = vbChecked Then reflectop = True Else reflectop = False
    If chkReflectIP = vbChecked Then reflectip = True Else reflectip = False
    
    crcTest.InitCustom bytes, poly, seed, reflectop, reflectop, xorop

End Sub

Private Sub cmdVisible_Click()
    If cmdVisible.Caption = "Show" Then
        cmdVisible.Caption = "Hide"
        crcTest.Visible = True
    Else
        cmdVisible.Caption = "Show"
        crcTest.Visible = False
    End If
End Sub

Private Sub Command1_Click()
    lblResult = Hex(crcTest.DoCRC(txtCRC, Len(txtCRC), False, seed))
    If lblResult = "0" Then lblResult = "error " & crcTest.GetLastError
    lblticks = "n/a"
End Sub

Private Sub Command10_Click()
    Dim looper As Long
    Dim its As Long
    
    lblticks = "Stated"
    
    ' do in a loop to get 1/2 MB data
    its = 524288 \ Cnt
    If its = 0 Then its = 1
    
    cTimer.StartTimer
    
    For looper = 1 To its - 1
        modbus_crc_16 Data, Cnt
    Next
    lblResult = Hex$(modbus_crc_16(Data, Cnt))

    cTimer.StopTimer
    ticks = cTimer.MilliSeconds
    If ticks = 0 Then ticks = 1
    
    lblticks = Format$(((Cnt * its / 1048576) / (ticks / 1000)), "0.000") & "  MB/s"

End Sub


Private Sub Command2_Click()
    Dim vData As Variant
    vData = CStr(txtCRC)
    lblResult = Hex(crcTest.DoCRCVar(vData))
    If lblResult = "0" Then lblResult = "error " & crcTest.GetLastError
    lblticks = "n/a"
End Sub

Private Sub Command3_Click()
    Dim vData As Variant
    vData = CDbl(numCRC)
    lblResult = Hex(crcTest.DoCRCVar(vData))
    If lblResult = "0" Then lblResult = "error " & crcTest.GetLastError
    lblticks = "n/a"
End Sub


Private Sub Command4_Click()
    Dim vData As Variant
    vData = CLng(numCRC)
    lblResult = Hex(crcTest.DoCRCVar(vData))
    If lblResult = "0" Then lblResult = "error " & crcTest.GetLastError
    lblticks = "n/a"
End Sub


Private Sub Command5_Click()
    Dim vData As Variant
    vData = CDate(numCRC)
    lblResult = Hex(crcTest.DoCRCVar(vData))
    If lblResult = "0" Then lblResult = "error " & crcTest.GetLastError
    lblticks = "n/a"
End Sub


Private Sub Command6_Click()
    Dim vData As Variant
    vData = CByte(numCRC)
    lblResult = Hex(crcTest.DoCRCVar(vData))
    If lblResult = "0" Then lblResult = "error " & crcTest.GetLastError
    lblticks = "n/a"
End Sub


Private Sub Command7_Click()
    Dim vData As Variant
    vData = CSng(numCRC)
    lblResult = Hex(crcTest.DoCRCVar(vData))
    If lblResult = "0" Then lblResult = "error " & crcTest.GetLastError
    lblticks = "n/a"
End Sub


Private Sub Command8_Click()
    Dim vData As Variant
    vData = CInt(numCRC)
    lblResult = Hex(crcTest.DoCRCVar(vData))
    If lblResult = "0" Then lblResult = "error " & crcTest.GetLastError
    lblticks = "n/a"
End Sub


Private Sub Command9_Click()
    CrcInit
    Command10.Enabled = True
    Command9.Enabled = False
End Sub

Private Sub crclist_Click()
    crcTest.CRCType = crclist.ListIndex
End Sub


Private Sub crcTest_AsyncFileCRC(ByVal Error As Long, ByVal Reference As Long, ByVal CRC As Long)
    On Error Resume Next    ' i wish c had this!
    
    If Error <> 0 Then
        txtAsyncRes(Reference) = "AsyncFile: Error = " & Error
    Else
        txtAsyncRes(Reference) = "AsyncFile: CRC   = " & Hex$(CRC)
    End If

End Sub

Private Sub crcTest_AsyncFileProgress(ByVal Reference As Long, ByVal Progress As Integer)
    On Error Resume Next
    barAsync(Reference).Value = Progress
End Sub


Private Sub Form_Load()
   
    Set cTimer = New CMMTimer
    
    Dim fnum As Integer
    fnum = FreeFile
    Open "testdata.dat" For Binary Access Read As #fnum
    Cnt = LOF(fnum)
    If Cnt = 0 Then
        MsgBox "require a data file call testdat.dat with some data"
        End
    End If
    
    ReDim Data(Cnt)
    
    Get #fnum, , Data
    Close #fnum

    fnum = FreeFile
    Open "testdata.out" For Binary Access Write As #fnum
    Put #fnum, , Data
    Close #fnum

    crclist.ListIndex = crcTest.CRCType

End Sub


Private Sub mnuQuit_Click()
    Unload Me
End Sub


