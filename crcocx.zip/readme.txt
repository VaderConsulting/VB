CRC Calculation Control
=======================

Version        1.5
Date           16/01/00
Copyright (c)  Chris Amos, 1998, 1999, 2000

Introduction
~~~~~~~~~~~~
This control (OCX) is really designed for VB4/5/6. It 
may work in other OCX containers but I haven't tried it.

The reason for using an OCX written in C for fairly 
simple algorythms are speed. In short the OCX is about 
500 times quicker even if you are only adding up bytes 
(it also skirts around the bug in VB where a byte 
becomes a short int when you compile the application, 
but I digress...)

Since version 1.5, most of the algorithms are rewritten 
in ASM so they are twice as fast again.

Usage
~~~~~
In VB you simply give the OCX a string and say what CRC 
to return, you have the option of showing a progress bar 
or passing the string in chunks. An example VB project 
is included.
You can also give it a file name, an array of bytes or a 
whole bunch of file names to do asynchronously in the 
background.

Installation
~~~~~~~~~~~~
This is a programmers tool, if you need to ask... Well, 
just in case, copy the OCX, the CNT and HLP file to a 
folder on your PC. Register the OCX 
("regsvr32 crcocx.ocx"). When you first use the help 
function in VB, you will have to lead it to the correct 
directory, after which it should remember it.

License
~~~~~~~
I have released this control as what I call 'swapware', 
this means you can use this control in any personal 
project for free (send me an email anyway for my intrest 
at freereg_crcocx@preface.co.uk). I would like to get 
something back so if you use this control to produce a 
shareware or comercial product, I would like a copy of 
that product, DO NOT email me an application, send me an 
email with a description, a URL to get the program and 
the regcode etc. If it a big app that is only distributed 
on CD send me details and we'll take it from there. The 
address for swaps is swapreg_crcocx@preface.co.uk

Support
~~~~~~~
As this product is free, I will not guarantee to answer 
any queries, I, and a few others, have tested it and it 
does what I wanted. 
Send any queries to: freesupt_crcocx@preface.co.uk

Source Code
~~~~~~~~~~~
I understand that commercial organisations must be able 
to guarantee continuity of support if they choose to use 
a component especially from a one-man-band. The best way 
I can ensure this is to make the source code available. 
If you wish to 'buy' the source code go to 
http://www.sw-reg.com and look up product id 201692. 
They will send the password to open the source code 
archive (http://www.sirocco.force9.co.uk/crcsrc.zip) and 
inform me of your purchase. This will not guarantee I will 
provide support and upgrades etc, it is your guarantee 
that YOU can support the component.

Implementation
~~~~~~~~~~~~~~
I have implemented a selection of CRCs detailed below:

0: XOR
   8 Bit Bitwise XOR
1: CRC32 
   This is the most widely used CRC, it expressed as 
   x^32,26,23,22,16,12,11,10,8,7,5,4,2,1,0. This is
   used in zip archives.
2: Adler
   I believe this is the method used in GZIP archives.
3: CRC16 
   Fairly widely used CRC, it expressed as 
   x^16,15,2,0.
4: CCITT
   Its a standard, but I have no idea who uses it,   
   16 x^16,12,5,0
5: 16 Bit Sum  
   Simply adds up the bytes, way quicker than VB
   and bug free. Sometimes called a longitudinal
   redundancy check (LRC) in specs, but there must 
   be more to something with a fancy name like that.
6: 32 Bit Sum
   As 16 bit sum, but bigger.
7: Private Custom type
   Please ignore this type.
8: CCITT Reflected and byte swapped (ie Motorola byte order)
   As use on ModBUS systems, variant on type 4, possibly 
   explains why I found no users of type 4.
   16 x^16,12,5,0
9: CCITT16 Reversed
   As 8 without the twist.   
   16 x^16,12,5,0
10:CRC8
   By request CRC, it is expressed as 
   x^8,5,4,3,0.
11:Custom
   By request, whatever you want 16 or 32 bit!

History
~~~~~~~
1.0	Initial release, requires a progress bar 
	control in VB proj 
    	that uses the control.
1.1	Fixed requirement for second progress bar.
1.2	Added ModBUS crc
1.3	CCITT16 Reversed
1.4 	Added DoCRCVar to CRC most things found in a 
	variant
	Added DoCRCByteArray to CRC a Byte array, gets 
	round some Unicode problems on Japanese systems
1.5 	Added 8 bit CRC, by request source supplied, 
	unsure of its use.
	Added custom 16 and 32 bit CRCs
	Added functions to retrieve crc as hex/dec string,
	for VB!
	Optimized most CRC calculations with ASM language.
	Added help
	Unsorted property page listbox and change size to
 	please VB
	Added GetLastError fx, call this if the crc is 0,
	if it is Genuinely 0, GetLastError will return 0,
 	else it returns
	Whatever error it got from the OS, could be 
	anything but 0!
	Added CRCFile fx
	Added CRCFileAsyncStart, CRCFileAsyncStop and 
	events!
