VERSION 5.00
Begin VB.Form frmMain 
   Caption         =   "Verify Password Demo Form"
   ClientHeight    =   1635
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   3900
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmMain.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   1635
   ScaleWidth      =   3900
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdClose 
      Caption         =   "&Close"
      Height          =   375
      Left            =   1920
      TabIndex        =   5
      Top             =   1080
      Width           =   1095
   End
   Begin VB.CommandButton cmdVerify 
      Caption         =   "&Verify"
      Default         =   -1  'True
      Height          =   375
      Left            =   720
      TabIndex        =   4
      Top             =   1080
      Width           =   1095
   End
   Begin VB.TextBox txtPassword 
      Height          =   285
      IMEMode         =   3  'DISABLE
      Left            =   1200
      PasswordChar    =   "*"
      TabIndex        =   3
      Top             =   600
      Width           =   1815
   End
   Begin VB.TextBox txtUsername 
      Height          =   285
      Left            =   1200
      TabIndex        =   2
      Top             =   240
      Width           =   1815
   End
   Begin VB.Label lblPassword 
      AutoSize        =   -1  'True
      Caption         =   "&Password:"
      Height          =   195
      Left            =   120
      TabIndex        =   1
      Top             =   600
      Width           =   750
   End
   Begin VB.Label lblUserName 
      AutoSize        =   -1  'True
      Caption         =   "&User Name:"
      Height          =   195
      Left            =   120
      TabIndex        =   0
      Top             =   240
      Width           =   840
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdClose_Click()
    Unload Me
    End
End Sub

Private Sub cmdVerify_Click()
    MsgBox "The password you supplied was " & VerifyWindowsLoginUserPassword(txtPassword.Text)
End Sub

Private Sub Form_Load()
    txtUsername = GetWindowsLoginUserID
    txtUsername.Enabled = False
End Sub
