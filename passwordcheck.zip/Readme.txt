http://www.vb-helper.com/HowTo/passchk.zip

	Purpose
Verify the user's password

	Method
Use the WNetVerifyPassword API function to verify that the user enters the correct password.

Note that this program doesn't seem to run in Windows NT. I don't have NT running right now so I cannot try it.

Thanks to David Roberts (davidr@vulcanind.com).

	Disclaimer
This example program is provided "as is" with no warranty of any kind. It is
intended for demonstration purposes only. In particular, it does no error
handling. You can use the example in any form, but please mention
www.vb-helper.com.
