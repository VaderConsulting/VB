Attribute VB_Name = "modVerifyPass"
'--
'Original Code by Geoff Glaze
'Written by Sam Huggill for the VB Square HowTo section
'Web: http://www.programmerz.com/vb/
'Email: vb@programmerz.com
'--

Option Explicit

Declare Function GetUserName Lib "advapi32.dll" Alias _
    "GetUserNameA" (ByVal lpBuffer As String, _
    nSize As Long) As Long

Private Declare Function WNetVerifyPassword Lib "mpr.dll" Alias _
    "WNetVerifyPasswordA" (ByVal lpszPassword As String, _
    ByRef pfMatch As Long) As Long

Public Function GetWindowsLoginUserID() As String
Dim buf As String
Dim buf_len As Long

    buf = Space$(400)
    buf_len = Len(buf)
    If GetUserName(buf, buf_len) <> 0 Then
        GetWindowsLoginUserID = Left$(buf, buf_len - 1)
    End If
End Function

Public Function VerifyWindowsLoginUserPassword(ByVal Password As String) As Boolean
    Dim rtn As Long, Match As Long
    rtn = WNetVerifyPassword(Password, Match)
    If rtn Then
        VerifyWindowsLoginUserPassword = False
    Else
        VerifyWindowsLoginUserPassword = (Match <> 0)
    End If
End Function
